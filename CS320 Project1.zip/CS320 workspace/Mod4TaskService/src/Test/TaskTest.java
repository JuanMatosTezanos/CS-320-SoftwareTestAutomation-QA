package Test;

import org.junit.jupiter.api.Test;
import taskservice.Task;

import static org.junit.jupiter.api.Assertions.*;

class TaskTest {

    private void assertThrowsForInvalidTask(String id, String name, String desc) {
        assertThrows(IllegalArgumentException.class, () -> new Task(id, name, desc));
    }

    @Test
    void testValidTaskCreation() {
        Task task = new Task("123", "Homework", "Complete math assignment.");
        assertAll(
                () -> assertEquals("123", task.getTaskId()),
                () -> assertEquals("Homework", task.getName()),
                () -> assertEquals("Complete math assignment.", task.getDescription())
        );
    }

    @Test
    void testInvalidInputs() {
        assertThrowsForInvalidTask(null, "Task", "Desc");
        assertThrowsForInvalidTask("12345678901", "Task", "Desc");
        assertThrowsForInvalidTask("123", null, "Desc");
        assertThrowsForInvalidTask("123", "ThisNameIsWayTooLongForTheLimit", "Desc");
        assertThrowsForInvalidTask("123", "Task", null);
        assertThrowsForInvalidTask("123", "Task", "This description exceeds the fifty-character limit and should fail.");
    }

    @Test
    void testBoundaryLengths() {
        assertEquals("1234567890", new Task("1234567890", "Task", "Desc").getTaskId());
        assertEquals("12345678901234567890", new Task("123", "12345678901234567890", "Desc").getName());
        assertEquals("12345678901234567890123456789012345678901234567890",
                new Task("123", "Task", "12345678901234567890123456789012345678901234567890").getDescription());
    }

    @Test
    void testSettersWork() {
        Task task = new Task("123", "Old", "Old Desc");
        task.setName("New");
        task.setDescription("New Desc");
        assertAll(
                () -> assertEquals("New", task.getName()),
                () -> assertEquals("New Desc", task.getDescription())
        );
    }

    @Test
    void testInvalidSetters() {
        Task task = new Task("123", "Good", "Good Desc");
        assertThrows(IllegalArgumentException.class, () -> task.setName(null));
        assertThrows(IllegalArgumentException.class, () -> task.setName("ThisNameIsWayTooLongForTheLimit"));
        assertThrows(IllegalArgumentException.class, () -> task.setDescription(null));
        assertThrows(IllegalArgumentException.class, () -> task.setDescription("This description exceeds the fifty-character limit and should fail."));
    }

    @Test
    void testEmptyAndSameValueStrings() {
        Task task = new Task("1", "", "");
        assertEquals("", task.getName());
        assertEquals("", task.getDescription());

        task.setName("");
        assertEquals("", task.getName());

        task.setDescription("");
        assertEquals("", task.getDescription());

        task.setName("Repeat");
        task.setName("Repeat");
        assertEquals("Repeat", task.getName());

        task.setDescription("Same");
        task.setDescription("Same");
        assertEquals("Same", task.getDescription());
    }

    @Test
    void testWhitespaceAndCaseSensitiveInputs() {
        Task t1 = new Task("456", "   ", "   ");
        assertEquals("   ", t1.getName());
        assertEquals("   ", t1.getDescription());

        Task t2 = new Task("789", "task", "description");
        assertEquals("task", t2.getName());
        assertEquals("description", t2.getDescription());
    }
}





