package Test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import taskservice.Task;
import taskservice.TaskService;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class TaskServiceTest {

    @Test
    void testAddTask() {
        TaskService service = new TaskService();
        Task task = new Task("123", "Task1", "Test Description");
        
        service.addTask(task);
        assertEquals(task, service.getTask("123"));
    }

    @Test
    void testAddTaskWithDuplicateIdThrowsException() {
        TaskService service = new TaskService();
        Task task1 = new Task("123", "Task1", "Desc1");
        Task task2 = new Task("123", "Task2", "Desc2"); // Same ID
        
        service.addTask(task1);
        assertThrows(IllegalArgumentException.class, () -> service.addTask(task2));
    }

    @Test
    void testDeleteTask() {
        TaskService service = new TaskService();
        Task task = new Task("123", "Task1", "Desc");
        
        service.addTask(task);
        service.deleteTask("123");
        
        assertNull(service.getTask("123"));
    }

    @Test
    void testDeleteNonexistentTaskThrowsException() {
        TaskService service = new TaskService();
        assertThrows(IllegalArgumentException.class, () -> service.deleteTask("999"));
    }

    @Test
    void testUpdateTaskName() {
        TaskService service = new TaskService();
        Task task = new Task("123", "Old Name", "Desc");
        
        service.addTask(task);
        service.updateTaskName("123", "New Name");
        
        assertEquals("New Name", service.getTask("123").getName());
    }

    @Test
    void testUpdateTaskDescription() {
        TaskService service = new TaskService();
        Task task = new Task("123", "Task1", "Old Desc");
        
        service.addTask(task);
        service.updateTaskDescription("123", "New Desc");
        
        assertEquals("New Desc", service.getTask("123").getDescription());
    }

    @Test
    void testUpdateNonexistentTaskThrowsException() {
        TaskService service = new TaskService();
        assertThrows(IllegalArgumentException.class, () -> service.updateTaskName("999", "New Name"));
        assertThrows(IllegalArgumentException.class, () -> service.updateTaskDescription("999", "New Desc"));
    }
}
