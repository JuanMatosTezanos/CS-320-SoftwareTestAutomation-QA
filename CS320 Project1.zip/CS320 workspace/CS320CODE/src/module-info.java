/**
 * 
 */
/**
 * 
 */
module CS320CODE {
	requires org.junit.jupiter.api;
}