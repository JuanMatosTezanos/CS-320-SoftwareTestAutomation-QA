package Test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import contactService.Contact;
import contactService.ContactService;

public class ContactServiceTest {
    private ContactService service;

    @BeforeEach
    void setUp() {
        // Create a new ContactService instance before each test
        service = new ContactService();
    }

    @Test
    @DisplayName("Test to Add a Contact and Verify Details")
    void testAddContact() {
        // Create a Contact object
        Contact contact = new Contact("1234567890", "Juan", "Matos", "1234567890", "123 Main St");

        // Add the Contact object to the service
        service.addContact(contact);

        // Retrieve the contact from the service using the contact ID
        Contact retrievedContact = service.getContact(contact.getContactId());

        // Verify the contact was added correctly
        assertNotNull(retrievedContact, "Contact was not added correctly.");
        assertEquals(contact.getFirstName(), retrievedContact.getFirstName(), "First name does not match.");
        assertEquals(contact.getLastName(), retrievedContact.getLastName(), "Last name does not match.");
        assertEquals(contact.getPhone(), retrievedContact.getPhone(), "Phone number does not match.");
        assertEquals(contact.getAddress(), retrievedContact.getAddress(), "Address does not match.");
    }

    @Test
    @DisplayName("Test to Update First Name")
    void testUpdateFirstName() {
        Contact contact = new Contact("1234567890", "Juan", "Matos", "1234567890", "123 Main St");
        service.addContact(contact);

        String newFirstName = "Carlos";
        service.updateFirstName(contact.getContactId(), newFirstName);

        // Verify the first name was updated
        assertEquals(newFirstName, service.getContact(contact.getContactId()).getFirstName(), "First name was not updated.");
    }

    @Test
    @DisplayName("Test to Delete Contact")
    void testDeleteContact() {
        Contact contact = new Contact("1234567890", "Juan", "Matos", "1234567890", "123 Main St");
        service.addContact(contact);

        // Delete the contact
        service.deleteContact(contact.getContactId());

        // Verify the contact is deleted
        assertNull(service.getContact(contact.getContactId()), "Contact should be deleted.");
    }
}
