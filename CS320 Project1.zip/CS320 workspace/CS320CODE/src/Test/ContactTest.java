package Test;

import org.junit.jupiter.api.Test;

import contactService.Contact;

import static org.junit.jupiter.api.Assertions.*;

public class ContactTest {

    @Test
    public void testContactConstructor_valid() {
        Contact contact = new Contact("1234567890", "Juan", "Matos", "1234567890", "123 Main St");
        
        assertEquals("1234567890", contact.getContactId());
        assertEquals("Juan", contact.getFirstName());
        assertEquals("Matos", contact.getLastName());
        assertEquals("1234567890", contact.getPhone());
        assertEquals("123 Main St", contact.getAddress());
    }

    @Test
    public void testInvalidContactId_null() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact(null, "Juan", "Matos", "1234567890", "123 Main St");
        });
    }

    @Test
    public void testInvalidFirstName_tooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1234567890", "JuanJuanJuan", "Matos", "1234567890", "123 Main St");
        });
    }

    @Test
    public void testInvalidPhone_invalidFormat() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1234567890", "Juan", "Matos", "abc1234567", "123 Main St");
        });
    }

    @Test
    public void testSetFirstName_valid() {
        Contact contact = new Contact("1234567890", "Juan", "Matos", "1234567890", "123 Main St");
        contact.setFirstName("Carlos");
        assertEquals("Carlos", contact.getFirstName());
    }

    @Test
    public void testSetFirstName_invalid() {
        Contact contact = new Contact("1234567890", "Juan", "Matos", "1234567890", "123 Main St");
        assertThrows(IllegalArgumentException.class, () -> {
            contact.setFirstName("CarlosCarlosCarlos");
        });
    }
}
