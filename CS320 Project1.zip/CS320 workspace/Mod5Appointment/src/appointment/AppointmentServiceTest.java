package appointment;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.Calendar;
import java.util.Date;
import static org.junit.jupiter.api.Assertions.*;

public class AppointmentServiceTest {
    private AppointmentService service;
    private Appointment appointment;

    @BeforeEach
    public void setUp() {
        service = new AppointmentService();
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, 1);
        Date futureDate = cal.getTime();
        appointment = new Appointment("A1", futureDate, "Test Appointment");
    }

    @Test
    public void testAddAppointment() {
        service.addAppointment(appointment);
        assertEquals(appointment, service.getAppointment("A1"));
    }

    @Test
    public void testAddDuplicateAppointmentIdThrowsException() {
        service.addAppointment(appointment);
        assertThrows(IllegalArgumentException.class, () -> {
            service.addAppointment(appointment);
        });
    }

    @Test
    public void testDeleteAppointment() {
        service.addAppointment(appointment);
        service.deleteAppointment("A1");
        assertNull(service.getAppointment("A1"));
    }

    @Test
    public void testDeleteNonExistentAppointmentThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteAppointment("NONEXIST");
        });
    }
}
