package appointment;

import org.junit.jupiter.api.Test;

import java.util.Calendar;
import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;

public class AppointmentTest {

    private Date getFutureDate(int daysFromToday) {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, daysFromToday);
        return cal.getTime();
    }

    private void assertThrowsForAppointment(String id, Date date, String description) {
        assertThrows(IllegalArgumentException.class, () -> new Appointment(id, date, description));
    }

    @Test
    public void testValidAppointment() {
        Date futureDate = getFutureDate(1);
        Appointment appt = new Appointment("1234567890", futureDate, "Doctor Visit");

        assertAll(
                () -> assertEquals("1234567890", appt.getAppointmentId()),
                () -> assertEquals(futureDate, appt.getAppointmentDate()),
                () -> assertEquals("Doctor Visit", appt.getDescription())
        );
    }

    @Test
    public void testNullIdThrowsException() {
        Date futureDate = getFutureDate(1);
        assertThrowsForAppointment(null, futureDate, "Checkup");
    }

    @Test
    public void testPastDateThrowsException() {
        Date pastDate = getFutureDate(-1);
        assertThrowsForAppointment("123", pastDate, "Checkup");
    }

    @Test
    public void testLongDescriptionThrowsException() {
        Date futureDate = getFutureDate(1);
        String longDesc = "This is a very long appointment description exceeding fifty characters!";
        assertThrowsForAppointment("123", futureDate, longDesc);
    }

    @Test
    public void testValidAppointmentWithBoundaryDateAndDescription() {
        Date futureDate = getFutureDate(1);
        String validDescription = "Short Description";

        Appointment appt = new Appointment("123", futureDate, validDescription);
        assertAll(
                () -> assertEquals("123", appt.getAppointmentId()),
                () -> assertEquals(futureDate, appt.getAppointmentDate()),
                () -> assertEquals(validDescription, appt.getDescription())
        );
    }

    @Test
    public void testEmptyDescription() {
        Date futureDate = getFutureDate(1);
        Appointment appt = new Appointment("123", futureDate, "");
        assertEquals("", appt.getDescription());
    }
}
