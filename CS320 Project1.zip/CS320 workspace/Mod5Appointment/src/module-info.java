/**
 * 
 */
/**
 * 
 */
module Mod5Appointment {
	requires java.base;
	requires org.junit.jupiter.api;
}